module.exports = {
  INVALID_PAGE_NAMES: ["admin", "index", "profile"]
};
