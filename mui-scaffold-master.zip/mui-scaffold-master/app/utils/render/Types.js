export default {
  GRID: 'GRID',
  BUTTON: "BUTTON",
  COMPONENT: "COMPONENT"
};
